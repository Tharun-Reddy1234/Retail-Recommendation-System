# Retail Recommendation System

A hybrid system using SVD and content-based filtering served via Flask.
