
from surprise import Dataset, Reader, SVD
from surprise.model_selection import train_test_split
import pandas as pd
import joblib

def train_svd_model(transaction_csv, save_path='models/svd_model.pkl'):
    df = pd.read_csv(transaction_csv)
    reader = Reader(rating_scale=(1, 5))
    data = Dataset.load_from_df(df[['user_id', 'product_id', 'rating']], reader)
    trainset, _ = train_test_split(data, test_size=0.2)
    model = SVD()
    model.fit(trainset)
    joblib.dump(model, save_path)
    return model

def recommend_svd(user_id, product_ids, model):
    predictions = [(pid, model.predict(user_id, pid).est) for pid in product_ids]
    recommendations = sorted(predictions, key=lambda x: x[1], reverse=True)
    return [pid for pid, _ in recommendations[:5]]
