
from app.recommender import recommend_svd
from app.content_based import recommend_content

def hybrid_recommend(user_id, known_users, product_ids, model, product_csv):
    if user_id in known_users:
        return recommend_svd(user_id, product_ids, model)
    else:
        return recommend_content(product_ids[0], product_csv)
