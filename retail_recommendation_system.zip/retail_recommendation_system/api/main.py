
from flask import Flask, request, jsonify
import pandas as pd
import joblib
from app.hybrid import hybrid_recommend

app = Flask(__name__)
model = joblib.load('models/svd_model.pkl')
known_users = pd.read_csv('data/users.csv')['user_id'].tolist()
product_ids = pd.read_csv('data/products.csv')['product_id'].tolist()

@app.route('/recommend', methods=['GET'])
def recommend():
    user_id = int(request.args.get('user_id'))
    recommendations = hybrid_recommend(
        user_id=user_id,
        known_users=known_users,
        product_ids=product_ids,
        model=model,
        product_csv='data/products.csv'
    )
    return jsonify({'recommended_product_ids': recommendations})

if __name__ == '__main__':
    app.run(debug=True)
